import azkviz.gui.MainMenu;

public class Main {
    public static void main(String[] args) {
        new MainMenu();
    }

    //TODO: Zobrazení výhry
    //TODO: Statistiky - celkové hry, kolikrát vyhrál hráč 1, kolikrát hráč 2
    //TODO: Refactor + reformat
    //TODO: Developerska dokumentace
    //TODO: Readme

}