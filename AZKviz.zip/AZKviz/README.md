# Použití
Před použitím se ujisti, že máš všechny potřebné soubory. Hru spustíš přes .jar soubor.

# Úprava otázek
Otázky lze upravít v souborech azkviz/otazky
## Finále
Písmeno;Otázka;Hlavní odpověď;Další odpověďi;Další odpověďi
## Semifinále
Otázka;Hlavní odpověď;Další odpověďi;Další odpověďi
## Náhradní otázky
Otázka;ano/ne